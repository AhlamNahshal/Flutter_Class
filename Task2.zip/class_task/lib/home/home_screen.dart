import 'package:flutter/material.dart';

import '../units/drawer.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Bull's Rent"),
        centerTitle: true,
        backgroundColor: const Color.fromARGB(255, 250, 235, 34),
      ),
      drawer: const Drawe(),
      body: const Center(
        child: Text(" Good Nighht "),
      ),
    );
  }
}
