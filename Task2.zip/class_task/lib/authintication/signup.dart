import 'package:flutter/material.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  TextEditingController email = TextEditingController();
  TextEditingController username = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController firstName = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        alignment: Alignment.bottomLeft,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SizedBox(
              height: 70,
            ),
            SizedBox(
              height: 170,
              width: 170,
              child: Image.asset(
                  "assets/5f278473ba11425ac488b1ed_taxi-success-1.png"),
            ),
            const Text("WELCOME",
                style: TextStyle(
                  fontSize: 40,
                  fontFamily: "Bungee",
                )),
            const Text("Sign Up to start your new journy ",
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.grey,
                )),
            const SizedBox(
              height: 10,
            ),
            TextField(
              controller: firstName,
              decoration: const InputDecoration(
                focusColor: Colors.amber,
                labelText: "First Name",
                labelStyle: TextStyle(fontWeight: FontWeight.bold),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10))),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            TextField(
              controller: username,
              decoration: const InputDecoration(
                focusColor: Colors.amber,
                labelText: "User Name",
                labelStyle: TextStyle(fontWeight: FontWeight.bold),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10))),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            TextField(
              controller: email,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(
                suffixIcon: Icon(Icons.email),
                focusColor: Colors.amber,
                labelText: "Email",
                labelStyle: TextStyle(fontWeight: FontWeight.bold),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10))),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            TextField(
              controller: password,
              obscureText: true,
              decoration: const InputDecoration(
                suffixIcon: Icon(Icons.remove_red_eye_outlined),
                focusColor: Colors.amber,
                labelText: "Password",
                labelStyle: TextStyle(fontWeight: FontWeight.bold),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10))),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.of(context).pushNamed('/login');
                  },
                  child: const Text("Aeredy have an account? Login here    "),
                ),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    String fN = firstName.text.toString();
                    String uN = username.text.toString();
                    String em = email.text.toString();
                    String pass = password.text.toString();
                    if (fN.isNotEmpty &&
                        uN.isNotEmpty &&
                        em.isNotEmpty &&
                        pass.isNotEmpty) {
                      Navigator.of(context).pushNamed('/home2');
                    }
                  },
                  child: const Text("GO"),
                ),
              ],
            ),
          ]),
        ),
      ),
    );
  }
}
