import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  var flage = false;
  TextEditingController userName = TextEditingController();
  TextEditingController password = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          alignment: Alignment.bottomLeft,
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SizedBox(
              height: 70,
            ),
            SizedBox(
              height: 170,
              width: 170,
              child: Image.asset(
                  "assets/5f278473ba11425ac488b1ed_taxi-success-1.png"),
            ),
            const Text("HELLO THERE,\nWELCOME BACK",
                style: TextStyle(
                  fontSize: 40,
                  fontFamily: "Bungee",
                )),
            const Text("Sign in to continue",
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.grey,
                )),
            const SizedBox(
              height: 10,
            ),
            TextField(
              controller: userName,
              decoration: const InputDecoration(
                focusColor: Colors.amber,
                labelText: "User Name",
                labelStyle: TextStyle(fontWeight: FontWeight.bold),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10))),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            TextField(
              controller: password,
              obscureText: true,
              decoration: const InputDecoration(
                suffixIcon: Icon(Icons.remove_red_eye_rounded),
                focusColor: Colors.amber,
                labelText: "Password",
                labelStyle: TextStyle(fontWeight: FontWeight.bold),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10))),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.of(context).pushNamed('/signup');
                  },
                  child: const Text("Don't have an account? SignUp here    "),
                ),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    String username = userName.text.toString();
                    String pass = password.text.toString();
                    if (username.isNotEmpty && pass.isNotEmpty) {
                      Navigator.of(context).pushNamed('/home2');
                    }
                  },
                  child: const Text("GO"),
                ),
              ],
            ),
          ]),
        ),
      ),
    );
  }
}
