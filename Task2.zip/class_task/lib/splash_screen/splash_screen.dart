import 'package:flutter/material.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 3), () {
      Navigator.of(context).pushNamed('/login');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color.fromARGB(255, 255, 207, 48),
        body: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const SizedBox(
            height: 100,
          ),
          Image.asset("assets/5f278473ba11425ac488b1ed_taxi-success-1.png"),
          const SizedBox(
            height: 120,
          ),
          const Text(
            "BULL'S\n RENT",
            style: TextStyle(
                fontFamily: "Bungee",
                fontSize: 70,
                color: Color.fromARGB(255, 91, 91, 91)),
          ),
          const SizedBox(
            height: 40,
          ),
          const Text("Nation wide Car rental app",
              style: TextStyle(
                color: Color.fromARGB(255, 120, 119, 119),
              ))
        ]));
  }
}
