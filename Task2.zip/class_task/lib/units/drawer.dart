import 'package:flutter/material.dart';

class Drawe extends StatefulWidget {
  const Drawe({super.key});

  @override
  State<Drawe> createState() => _DraweState();
}

class _DraweState extends State<Drawe> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: const Color.fromARGB(255, 243, 235, 211),
      child: ListView(
        children: [
          const UserAccountsDrawerHeader(
            currentAccountPicture: CircleAvatar(
              backgroundImage: AssetImage('assets/O.jpeg'),
            ),
            accountName: Text("Ahlam Nahshal"),
            accountEmail: Text("ahlam@gmal.com"),
          ),
          ListTile(
            title: const Text("Home Screen"),
            onTap: () {
              Navigator.of(context).pushNamed('/home2');
            },
            splashColor: const Color.fromARGB(255, 191, 175, 29),
          ),
          ListTile(
            title: const Text("Sign Out"),
            onTap: () {
              Navigator.of(context).pushNamed('/login');
            },
            splashColor: const Color.fromARGB(255, 191, 175, 29),
          ),
        ],
      ),
    );
  }
}
